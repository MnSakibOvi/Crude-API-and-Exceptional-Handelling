package com.example.tutorial.student;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
public class StudentService {
    private final Repository repository;


    public StudentService(Repository repository) {
        this.repository = repository;

    }


    public List<Student> getStudent(String email) {
        if (email != null || !email.isEmpty()) {
            List<Student> list = new ArrayList<>();
            Optional<Student> studentByEmail = repository.findStudentByEmail(email);
            if (studentByEmail.isPresent()) {
                list.add(studentByEmail.get());
            } else {
                throw new IllegalArgumentException("Student not found.");
            }
            return list;
        } else {
            return new ArrayList<Student>();
        }

    }

    public void addNewStudent(Student student) {

        Optional<Student> studentByEmail = repository.findStudentByEmail(student.getEmail());
        if (studentByEmail.isPresent()) {
            throw new IllegalStateException("email taken");
        } else {
            repository.save(student);
        }


    }

    @Transactional
    public void deleteStudent(Long studentId) {
        boolean exist = repository.existsById(studentId);
        if (!exist) {
            throw new IllegalStateException("ID doesn`t exist");
        } else {
            repository.deleteById(studentId);
        }

    }


//    public void UpdateStudent(Student student) {
//        Student Tempstudent;
//        boolean exist = repository.existsById(student.getId());
//        if (!exist) {
//            throw new IllegalStateException("ID doesn`t exist");
//        } else {
//
//            Optional<Student> studentOptional = repository.findById(student.getId());
//            repository.Update(studentOptional);
//
//            }
//
//        }
    @Transactional
    public void UpdateStudent(Long studentId,
                              String name,
                              String email) {
        Student student = repository.findById(studentId).orElseThrow(()->new IllegalStateException("Student with id "+studentId+" does not exist"));
        if((name != null) &&
                (name.length() > 0)
                && !Objects.equals(student.getName(), name)){
            student.setName(name);
        }
        if(email != null &&
            email.length()>0 &&
            !Objects.equals(student.getEmail(),email)){
            Optional<Student> studentOptional = repository.findStudentByEmail(email);
            if(studentOptional.isPresent()){
                throw new IllegalStateException("email Taken already");
            }
            student.setEmail(email);
        }
       repository.save(student);

    }
}

