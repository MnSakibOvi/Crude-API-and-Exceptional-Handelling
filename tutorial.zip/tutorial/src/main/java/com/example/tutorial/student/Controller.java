package com.example.tutorial.student;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping(path = "/student")

public class Controller {

    private final StudentService studentService;

    @Autowired
    public Controller(StudentService studentService) {
        this.studentService = studentService;
    }


    @GetMapping(path = "/v1/search/{email}")
    public ResponseEntity getStudent(@PathVariable String email) {
        System.out.println(email);
        return new ResponseEntity(studentService.getStudent(email), HttpStatus.OK);


    }

    @PostMapping(path = "/v1/save")
    public ResponseEntity registerNewStudent(@RequestBody Student student) {
        System.out.println(student.getEmail());
        studentService.addNewStudent(student);
        return new ResponseEntity("Save successfully", HttpStatus.CREATED);
    }

    @DeleteMapping(path = "/v1/delete/{studentId}")
    public ResponseEntity deleteStudent(@PathVariable("studentId") Long studentId) {
        studentService.deleteStudent(studentId);
        return new ResponseEntity<>("Delete successfully", HttpStatus.OK);

    }

    @PutMapping(path = "/v1/update/{studentId}")
    public ResponseEntity updateStudent(@PathVariable("studentId") Long studentId,
                                        @RequestParam(required = false) String name,
                                        @RequestParam(required = false) String email) {
        studentService.UpdateStudent(studentId, name, email);
        return new ResponseEntity<>("SuccessfullyUpdated", HttpStatus.OK);

    }

}
