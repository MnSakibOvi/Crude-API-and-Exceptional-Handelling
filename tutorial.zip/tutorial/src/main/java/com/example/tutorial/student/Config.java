package com.example.tutorial.student;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.LocalDate;
import java.time.Month;
import java.util.List;

import static java.time.Month.*;


@Configuration
public class Config {
    @Bean
    CommandLineRunner commandLineRunner(Repository repository){
        return args->{
          Student sakib =  new Student(

                    "sakib",
                    "sakib19@gmail.com",
                    LocalDate.of(1800, JANUARY,5)

            );
            Student alex= new Student(

                    "alex",
                    "alex19@gmail.com",
                    LocalDate.of(1998, JANUARY,5)


            );
            Student sakib2 =  new Student(

                    "sakibokdas",
                    "sakib19dsad@gmail.com",
                    LocalDate.of(1800, DECEMBER,5)

            );
            Student alex2= new Student(

                    "alex Brenzamin",
                    "alex19sadsa@gmail.com",
                    LocalDate.of(1900, FEBRUARY,5)


            );
            repository.saveAll(
                    List.of(sakib,alex,sakib2,alex2)
            );
        };
    }
}
