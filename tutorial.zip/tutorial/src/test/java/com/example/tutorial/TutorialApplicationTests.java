package com.example.tutorial;

import com.example.tutorial.student.Repository;
import com.example.tutorial.student.Student;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.assertj.core.api.Assertions;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

import static java.time.Month.JANUARY;

@SpringBootTest
@AutoConfigureMockMvc(addFilters = false)
class TutorialApplicationTests {
	@Autowired
	MockMvc mockMvc;

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private Repository repository;
 	
//Search api---------------------------->
	@Test
	@Transactional
	void getStudent_Success() throws Exception {


		Student student = new Student();
		student.setEmail("55555@gmail.com");
		student.setName("huasdfjhsadkf");
		student.setDob(LocalDate.of(1998, JANUARY,5));
		Student studentSaved = repository.save(student);


		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders
						.get("/api/student/v1/search/"+studentSaved.getEmail())
						.contextPath("/api"))
				.andDo(MockMvcResultHandlers.print())
				.andExpect(MockMvcResultMatchers.status().isOk())

				.andExpect(MockMvcResultMatchers.jsonPath("$", Matchers.hasSize(1)))
				.andExpect(MockMvcResultMatchers.jsonPath("$[0].email", Matchers.is(student.getEmail())))

				.andReturn();



	}

	@Test
	@Transactional
	void getStudent_notFound() throws Exception {
		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders
						.get("/api/student/v1/search/sakib19ssa@gmail.com")
						.contextPath("/api"))
				.andDo(MockMvcResultHandlers.print())
				.andExpect(MockMvcResultMatchers.status().isNotFound())
				.andExpect(MockMvcResultMatchers.jsonPath("$.msg", Matchers.is("Student not found.")))
				.andReturn();
	}
	@Test
	@Transactional
	void getConflict() throws Exception {
		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders
						.get("/api/student/v1/search/")
						.contextPath("/api"))
				.andDo(MockMvcResultHandlers.print())
				.andExpect(MockMvcResultMatchers.status().isNotFound())
				.andReturn();
	}
	//Save api---------------------------->
	@Test
	@Transactional
	void postStudentok() throws Exception {
		Student student = new Student();
		student.setEmail("mnsakibjgasdda@gmail.com");
		student.setName("huasdfjhsadkf");
		student.setDob(LocalDate.of(1998, JANUARY,5));
	
		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders
					.post("/api/student/v1/save")
					.contextPath("/api")
						.contentType(MediaType.APPLICATION_JSON)
						.content(objectMapper.writeValueAsString(student)))
				.andDo(MockMvcResultHandlers.print())
				.andExpect((ResultMatcher) MockMvcResultMatchers.status().isCreated())
				.andReturn();
	}
	@Test
	@Transactional
	void postStudentEmailExist() throws Exception {
		Student student = new Student();
		student.setEmail("sakib19@gmail.com");
		student.setName("huasdfjhsadkf");
		student.setDob(LocalDate.of(1998, JANUARY,5));

		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders
						.post("/api/student/v1/save")
						.contextPath("/api")
						.contentType(MediaType.APPLICATION_JSON)
						.content(objectMapper.writeValueAsString(student)))
				.andDo(MockMvcResultHandlers.print())
				.andExpect((ResultMatcher) MockMvcResultMatchers.status().isInternalServerError())
				.andReturn();
	}
	//DeleteAPI--------------------------------------------------------------------------------------------------------->
	@Test
	@Transactional
	void DeletStudentExist() throws  Exception{



		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders
						.delete("/api/student/v1/delete/1")
						.contextPath("/api"))
				.andDo(MockMvcResultHandlers.print())
				.andExpect(MockMvcResultMatchers.status().isOk())
				.andReturn();

	}
	@Test
	@Transactional
	void DeletStudentNotExist()throws  Exception{
		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders
						.delete("/api/student/v1/delete/10")
						.contextPath("/api"))
				.andDo(MockMvcResultHandlers.print())
				.andExpect(MockMvcResultMatchers.status().isInternalServerError())
				.andReturn();

	}

//update /put  api----------------------------------------------------------------------------------------------------->
 	@Test
	//@Transactional
	public void updateStudent_Successfull()throws  Exception{
		 MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders
						 .put("/api/student/v1/update/1")
						 .param("name","Istiak")
						 .param("email","monenai.com")
						 .contextPath("/api"))
				 .andDo(MockMvcResultHandlers.print())
				 .andExpect(MockMvcResultMatchers.status().isOk())
				 .andReturn();

	 }
	@Test
	@Transactional
	public void updateStudent_NotSuccessfull()throws  Exception{
		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders
						.put("/api/student/v1/update/10")
						.param("name","Istiak")
						.param("email","monenai.com")
						.contextPath("/api"))
				.andDo(MockMvcResultHandlers.print())
				.andExpect(MockMvcResultMatchers.status().isInternalServerError())
				.andReturn();

	}

}
